<div id="layoutSidenav_nav">
    <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
        <div class="sb-sidenav-menu">
            <div class="nav">
            <div class="sb-sidenav-menu-heading">Menu</div>
                <a class="nav-link" href="../Pakaian/index.php">
                    <div class="sb-nav-link-icon"><i class="fas fa-table"></i></div>
                    List Pakaian
                </a>
                <a class="nav-link" href="../Pakaian/form_pakaian.php">
                    <div class="sb-nav-link-icon"><i class="fas fa-table"></i></div>
                    Form Pakaian
                </a>

                <div class="sb-sidenav-menu-heading">Interface</div>
                <a class="nav-link" href="../Pesanan/index.php">
                    <div class="sb-nav-link-icon"><i class="fas fa-table"></i></div>
                    List Pesanan
                </a>
                <a class="nav-link" href="../Pesanan/form_pesanan.php">
                    <div class="sb-nav-link-icon"><i class="fas fa-table"></i></div>
                    Form Pesanan
                </a>
            
                <div class="sb-sidenav-menu-heading">Addons</div>
                <a class="nav-link" href="../Tipe_Pakaian/index.php">
                    <div class="sb-nav-link-icon"><i class="fas fa-table"></i></div>
                    List Tipe Pakaian
                </a>
                <a class="nav-link" href="../Tipe_Pakaian/form_tipe_pakaian.php">
                    <div class="sb-nav-link-icon"><i class="fas fa-table"></i></div>
                    Form Tipe Pakaian
                </a>

            </div>
        </div>
        <div class="sb-sidenav-footer">
            <div class="small">Logged in as:</div>
            Start Bootstrap
        </div>
    </nav>
</div>