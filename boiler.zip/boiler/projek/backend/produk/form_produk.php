<?php 
require_once '../../database/dbkoneksi.php';

?>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css"> 
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

<form method="POST" action="../proses/produk/proses_produk.php">
  <div class="form-group row">
    <label for="text" class="col-4 col-form-label">Nama Produk</label> 
    <div class="col-8">
        <input id="nama" name="nama" type="text" class="form-control">    
    </div>
  </div>
  <div class="form-group row">
    <label for="text1" class="col-4 col-form-label">Kode Merk</label> 
    <div class="col-8">
      <input id="merk_id" name="merk_id" type="text" class="form-control">
    </div>
  </div>
  <div class="form-group row">
    <label for="text2" class="col-4 col-form-label">Stok</label> 
    <div class="col-8">
      <input id="stok" name="stok" type="text" class="form-control">
    </div>
  </div>
  <div class="form-group row">
    <label for="text3" class="col-4 col-form-label">Harga</label> 
    <div class="col-8">
      <input id="harga" name="harga" type="text" class="form-control">
    </div>
  </div>
  <div class="form-group row">
    <label for="text4" class="col-4 col-form-label">Berat</label> 
    <div class="col-8">
      <input id="berat" name="berat" type="text" class="form-control">
    </div>
  </div>
  
  <div class="form-group row">
    <label class="col-4">Jenis Produk</label> 
    <div class="col-8">
                    <?php
                      require_once('../../database/dbkoneksi.php');

                      $sql_jenis_produk = "SELECT * FROM jenis_produk";
                      $rs_jenis_produk = $dbh->query($sql_jenis_produk);
                    ?>
                    <select id="jenis_produk_id" name="jenis_produk_id" class="form-control">
                      <?php
                      foreach ($rs_jenis_produk as $row_jenis_produk) {
                      ?>
                      <option value="<?= $row_jenis_produk['id'] ?>"><?= $row_jenis_produk['jenis_produk'] ?></option>
                      <?php
                      }
                      ?>
                    </select>
                    <div class="form-group row">
                  <div class="offset-4 col-8">
                    <button name="proses" type="submit" class="btn btn-primary"
                      value="Simpan">Submit</button>
                  </div>
                </div>
                  
    </div>
</form>
