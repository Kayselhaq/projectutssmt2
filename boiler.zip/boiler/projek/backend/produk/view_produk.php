<?php 
require_once '../../database/dbkoneksi.php';
?>

<?php
    // Mendapatkan nilai id dari parameter GET
    $_id = $_GET['id'];

    // Membuat query SQL untuk mengambil data produk dengan id tertentu
    $sql = "SELECT * FROM produk WHERE id=?";
    $st = $dbh->prepare($sql);

    // Menjalankan query dengan parameter id yang telah didapatkan sebelumnya
    $st->execute([$_id]);

    // Mengambil hasil query dan menyimpannya ke dalam variabel $row
    $row = $st->fetch();
?>

<!-- Menampilkan data produk dalam bentuk tabel -->
<table class="table table-striped">
    <tbody>
        <tr>
            <td>ID</td>
            <td><?=$row['id']?></td>
        </tr>
        <tr>
            <td>Nama</td>
            <td><?=$row['nama']?></td>
        </tr>
        <tr>
            <td>Kode Merk</td>
            <td><?=$row['merk_id']?></td>
        </tr>
        <tr>
            <td>Stok</td>
            <td><?=$row['stok']?></td>
        </tr>
        <tr>
            <td>Harga</td>
            <td><?=$row['harga']?></td>
        </tr>
        <tr>
            <td>Berat</td>
            <td><?=$row['berat']?></td>
        </tr>
        <tr>
            <td>Kode Produk</td>
            <td><?=$row['jenis_produk_id']?></td>
        </tr>
    </tbody>
</table>